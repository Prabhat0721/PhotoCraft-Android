package com.prabhat.photocraft

import android.app.Activity
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.OutputStream
import java.util.ArrayDeque
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

private const val BG = 0xFF101114.toInt()
private const val PANEL = 0xFF1A1C21.toInt()
private const val ACCENT = 0xFFB8F36B.toInt()
private const val MUTED = 0xFF9A9DA7.toInt()

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var toolPanel: LinearLayout
    private var original: Bitmap? = null
    private var previewBitmap: Bitmap? = null
    private var sourceUri: Uri? = null
    private var state = EditState()
    private val undoStack = ArrayDeque<EditState>()
    private val redoStack = ArrayDeque<EditState>()
    private var applying = false
    private var selectedHslColor = "Red"
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(16), dp(10), dp(16), dp(12)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text = "PhotoCraft"; textSize = 25f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }
        val undo = smallButton("↶") { undo() }; val redo = smallButton("↷") { redo() }
        header.addView(brand); header.addView(spacer); header.addView(undo); header.addView(redo)
        root.addView(header, LinearLayout.LayoutParams(-1, dp(48)))
        status = TextView(this).apply { text = "A little studio for your photos"; textSize = 12f; setTextColor(MUTED); setPadding(0, dp(2), 0, dp(8)) }
        root.addView(status)
        val previewCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(PANEL); clipToOutline = true }
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true; contentDescription = "Photo preview" }
        previewCard.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        val empty = TextView(this).apply { text = "Choose a photo to begin\nYour original stays untouched"; gravity = Gravity.CENTER; textSize = 15f; setTextColor(MUTED) }
        previewCard.addView(empty, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(previewCard, LinearLayout.LayoutParams(-1, 0, 1.1f).apply { bottomMargin = dp(12) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("＋  Add photo", false) { pickImage.launch("image/*") }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) })
        actions.addView(actionButton("Export JPEG  ↗", true) { exportJpeg() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(6) })
        root.addView(actions)
        val tabs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setPadding(0, dp(12), 0, dp(8)) }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Adjust", "HSL", "Looks", "Crop", "Color grade").forEach { name -> tabRow.addView(smallButton(name) { showTools(name) }) }
        tabs.addView(tabRow); root.addView(tabs)
        toolPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(PANEL) }
        val scroll = ScrollView(this).apply { isFillViewport = false; addView(toolPanel) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(228)))
        setContentView(root)
        showTools("Adjust")
    }

    private fun showTools(tab: String) {
        toolPanel.removeAllViews()
        when (tab) {
            "Adjust" -> {
                val heading = label("LIGHT & COLOR")
                toolPanel.addView(heading)
                listOf("Exposure", "Brightness", "Contrast", "Highlights", "Shadows", "Whites", "Blacks", "Temperature", "Tint", "Saturation", "Vibrance").forEach { key -> addSlider(key, state.values[key] ?: 0f, -100, 100) { v -> updateValue(key, v / 100f) } }
                toolPanel.addView(actionButton("Reset adjustments", false) { pushUndo(); state = EditState(filter = state.filter); renderPreview() })
            }
            "HSL" -> {
                toolPanel.addView(label("8-COLOUR HSL MIXER"))
                val colors = listOf("Red", "Orange", "Yellow", "Green", "Aqua", "Blue", "Purple", "Magenta")
                val colorRows = colors.chunked(4)
                colorRows.forEach { names ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    names.forEach { name ->
                        val selected = selectedHslColor == name
                        row.addView(actionButton(name, selected) { selectedHslColor = name; showTools("HSL") }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                    }
                    toolPanel.addView(row)
                }
                toolPanel.addView(TextView(this).apply { text = "$selectedHslColor · Hue / Saturation / Luminance"; textSize = 12f; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(2)) })
                listOf("Hue", "Saturation", "Luminance").forEach { component ->
                    val key = "HSL_${selectedHslColor}_$component"
                    addSlider(component, state.values[key] ?: 0f, -100, 100) { value -> updateValue(key, value / 100f) }
                }
                toolPanel.addView(actionButton("Reset $selectedHslColor HSL", false) {
                    pushUndo(); listOf("Hue", "Saturation", "Luminance").forEach { state.values["HSL_${selectedHslColor}_$it"] = 0f }; renderPreview(); showTools("HSL")
                })
            }
            "Looks" -> {
                toolPanel.addView(label("FILTERS & PRESETS"))
                val names = listOf("Original", "Warm", "Cool", "Mono", "Fade", "Vivid", "Golden", "Moody")
                names.chunked(4).forEach { rowNames ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    rowNames.forEach { name -> row.addView(actionButton(name, name == state.filter) { pushUndo(); state = state.copy(filter = name); renderPreview(); showTools("Looks") }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }) }
                    toolPanel.addView(row)
                }
            }
            "Crop" -> {
                toolPanel.addView(label("COMPOSITION"))
                toolPanel.addView(TextView(this).apply { text = "Quick crop uses a centered square. Original image is preserved until export."; setTextColor(MUTED); textSize = 12f; setPadding(0, dp(8), 0, dp(8)) })
                toolPanel.addView(actionButton("Crop to square", true) { cropSquare() })
                toolPanel.addView(actionButton("Rotate 90°", false) { rotatePhoto() })
            }
            else -> {
                toolPanel.addView(label("3-WAY COLOUR GRADING"))
                toolPanel.addView(TextView(this).apply { text = "Choose a tint on each colour wheel, then adjust its strength."; textSize = 12f; setTextColor(MUTED); setPadding(0, 0, 0, dp(8)) })
                listOf("Shadows", "Midtones", "Highlights").forEach { region ->
                    toolPanel.addView(TextView(this).apply { text = region.uppercase(); textSize = 12f; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(2)) })
                    val key = "Grade_${region}_Hue"
                    val wheel = ColorWheelView(this, state.values[key] ?: 0f) { hue -> if (!applying) { state.values[key] = hue; renderPreview() } }
                    toolPanel.addView(wheel, LinearLayout.LayoutParams(-1, dp(116)))
                    val strengthKey = "Grade_${region}_Strength"
                    addSlider("$region intensity", state.values[strengthKey] ?: 0f, 0, 100) { value -> updateValue(strengthKey, value / 100f) }
                }
                toolPanel.addView(actionButton("Reset colour grading", false) {
                    pushUndo(); listOf("Shadows", "Midtones", "Highlights").forEach { region -> state.values["Grade_${region}_Hue"] = 0f; state.values["Grade_${region}_Strength"] = 0f }; renderPreview(); showTools("Color grade")
                })
                toolPanel.addView(actionButton("Apply cinematic grade", true) { pushUndo(); state = state.copy(filter = "Moody"); state.values["Contrast"] = 0.12f; state.values["Saturation"] = 0.08f; renderPreview() })
            }
        }
    }

    private fun addSlider(name: String, current: Float, minV: Int, maxV: Int, changed: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(3), 0, dp(3)) }
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        line.addView(TextView(this).apply { text = name; textSize = 13f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, -2, 1f))
        val valueText = TextView(this).apply { text = "${(current * 100).toInt()}"; textSize = 12f; setTextColor(ACCENT) }
        line.addView(valueText); row.addView(line)
        val bar = SeekBar(this).apply { max = maxV - minV; progress = ((current * 100).toInt() - minV).coerceIn(0, max); progressTintList = android.content.res.ColorStateList.valueOf(ACCENT); thumbTintList = android.content.res.ColorStateList.valueOf(ACCENT) }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { val value = progress + minV; valueText.text = value.toString(); if (fromUser && !applying) changed(value) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) { if (!applying) pushUndo() }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        row.addView(bar); toolPanel.addView(row)
    }

    private fun updateValue(key: String, value: Float) { state.values[key] = value; renderPreview() }
    private fun pushUndo() { undoStack.addLast(state.deepCopy()); while (undoStack.size > 30) undoStack.removeFirst(); redoStack.clear() }
    private fun undo() { if (undoStack.isNotEmpty()) { redoStack.addLast(state.deepCopy()); state = undoStack.removeLast(); renderPreview(); showTools("Adjust") } }
    private fun redo() { if (redoStack.isNotEmpty()) { undoStack.addLast(state.deepCopy()); state = redoStack.removeLast(); renderPreview(); showTools("Adjust") } }

    private fun loadImage(uri: Uri) {
        try {
            sourceUri = uri
            contentResolver.openInputStream(uri).use { stream -> original = BitmapFactory.decodeStream(stream) }
            val src = original ?: throw IllegalStateException("Image could not be decoded")
            val maxSide = 1800
            previewBitmap = if (max(src.width, src.height) > maxSide) {
                val scale = maxSide.toFloat() / max(src.width, src.height)
                Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
            } else src.copy(Bitmap.Config.ARGB_8888, true)
            state = EditState(); undoStack.clear(); redoStack.clear()
            status.text = "${src.width} × ${src.height}  ·  Original preserved"
            renderPreview(); showTools("Adjust")
        } catch (e: Exception) { toast("Could not open this photo") }
    }

    private fun renderPreview() {
        val src = previewBitmap ?: run { preview.setImageDrawable(null); return }
        preview.setImageBitmap(process(src, state))
        status.text = "${src.width} × ${src.height}  ·  ${state.filter}"
    }

    private fun process(src: Bitmap, s: EditState): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(src.width * src.height); src.getPixels(pixels, 0, src.width, 0, 0, src.width, src.height)
        val v = s.values
        val exposure = 2.0.pow((v["Exposure"] ?: 0f).toDouble()).toFloat()
        val brightness = (v["Brightness"] ?: 0f) * 0.55f
        val contrast = 1f + (v["Contrast"] ?: 0f) * 1.5f
        val saturation = 1f + (v["Saturation"] ?: 0f) * 1.4f
        val vibrance = (v["Vibrance"] ?: 0f)
        val temp = (v["Temperature"] ?: 0f) * 0.32f
        val tint = (v["Tint"] ?: 0f) * 0.22f
        val highlights = (v["Highlights"] ?: 0f) / 100f
        val shadows = (v["Shadows"] ?: 0f) / 100f
        val whites = (v["Whites"] ?: 0f) / 100f
        val blacks = (v["Blacks"] ?: 0f) / 100f
        for (i in pixels.indices) {
            val c = pixels[i]; var r = Color.red(c) / 255f; var g = Color.green(c) / 255f; var b = Color.blue(c) / 255f
            r = r * exposure + brightness + temp + tint; g = g * exposure + brightness - tint * .25f; b = b * exposure + brightness - temp + tint
            r = (r - .5f) * contrast + .5f; g = (g - .5f) * contrast + .5f; b = (b - .5f) * contrast + .5f
            val lum = (r * .2126f + g * .7152f + b * .0722f).coerceIn(0f, 1f)
            val shadowWeight = (1f - lum).pow(2); val highlightWeight = lum.pow(2)
            val tonal = shadows * shadowWeight + highlights * highlightWeight + blacks * (1f-lum) + whites * lum
            r += tonal; g += tonal; b += tonal
            val gray = (r * .2126f + g * .7152f + b * .0722f)
            val sat = saturation + vibrance * (1f - (r - g).absoluteValue().coerceAtMost(1f))
            r = gray + (r-gray)*sat; g = gray + (g-gray)*sat; b = gray + (b-gray)*sat
            when (s.filter) {
                "Warm", "Golden" -> { r *= 1.08f; g *= 1.02f; b *= if (s.filter == "Golden") .84f else .92f }
                "Cool" -> { r *= .91f; b *= 1.08f }
                "Mono" -> { r = gray; g = gray; b = gray }
                "Fade" -> { r = r * .82f + .09f; g = g * .82f + .09f; b = b * .82f + .09f }
                "Vivid" -> { r = (r-.5f)*1.18f+.5f; g = (g-.5f)*1.18f+.5f; b = (b-.5f)*1.18f+.5f }
                "Moody" -> { r = (r-.5f)*1.15f+.5f; g = (g-.5f)*1.15f+.5f; b = (b-.5f)*1.15f+.5f; b *= .94f }
            }
            // 8-band HSL mixer: each band affects only pixels near that source hue.
            val hsl = rgbToHsl(r.coerceIn(0f, 1f), g.coerceIn(0f, 1f), b.coerceIn(0f, 1f))
            val bands = listOf("Red", "Orange", "Yellow", "Green", "Aqua", "Blue", "Purple", "Magenta")
            val centers = floatArrayOf(0f, 30f, 60f, 120f, 180f, 220f, 275f, 320f)
            var hueShift = 0f; var satShift = 0f; var lumShift = 0f; var totalWeight = 0f
            for (bandIndex in bands.indices) {
                val delta = hueDistance(hsl[0], centers[bandIndex])
                val weight = (1f - delta / 32f).coerceIn(0f, 1f)
                if (weight > 0f) {
                    val band = bands[bandIndex]
                    hueShift += (v["HSL_${band}_Hue"] ?: 0f) * 45f * weight
                    satShift += (v["HSL_${band}_Saturation"] ?: 0f) * weight
                    lumShift += (v["HSL_${band}_Luminance"] ?: 0f) * 0.35f * weight
                    totalWeight += weight
                }
            }
            if (totalWeight > 0f) {
                hsl[0] = (hsl[0] + hueShift).let { ((it % 360f) + 360f) % 360f }
                hsl[1] = (hsl[1] * (1f + satShift)).coerceIn(0f, 1f)
                hsl[2] = (hsl[2] + lumShift).coerceIn(0f, 1f)
                val mixed = hslToRgb(hsl[0], hsl[1], hsl[2]); r = mixed[0]; g = mixed[1]; b = mixed[2]
            }
            // Three-way colour grading with independent hue and intensity for each tonal range.
            val currentLum = (r * .2126f + g * .7152f + b * .0722f).coerceIn(0f, 1f)
            for (region in listOf("Shadows", "Midtones", "Highlights")) {
                val strength = (v["Grade_${region}_Strength"] ?: 0f).coerceIn(0f, 1f)
                if (strength > 0f) {
                    val weight = when (region) {
                        "Shadows" -> (1f - currentLum).pow(2)
                        "Highlights" -> currentLum.pow(2)
                        else -> (1f - kotlin.math.abs(currentLum - .5f) * 2f).coerceIn(0f, 1f)
                    } * strength * .32f
                    val hue = (((v["Grade_${region}_Hue"] ?: 0f) * 180f) + 360f) % 360f
                    val tint = hslToRgb(hue, 1f, .5f)
                    r += (tint[0] - .5f) * weight; g += (tint[1] - .5f) * weight; b += (tint[2] - .5f) * weight
                }
            }
            pixels[i] = Color.argb(Color.alpha(c), (r*255).toInt().coerceIn(0,255), (g*255).toInt().coerceIn(0,255), (b*255).toInt().coerceIn(0,255))
        }
        out.setPixels(pixels, 0, src.width, 0, 0, src.width, src.height)
        return out
    }

    private fun cropSquare() {
        val src = previewBitmap ?: return toast("Choose a photo first")
        pushUndo(); val side = min(src.width, src.height); val x = (src.width-side)/2; val y = (src.height-side)/2
        previewBitmap = Bitmap.createBitmap(src, x, y, side, side); renderPreview(); toast("Square crop applied")
    }
    private fun rotatePhoto() {
        val src = previewBitmap ?: return toast("Choose a photo first")
        pushUndo(); val matrix = android.graphics.Matrix().apply { postRotate(90f) }
        previewBitmap = Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true); renderPreview()
    }
    private fun exportJpeg() {
        val src = original ?: return toast("Choose a photo first")
        try {
            val edited = process(src, state)
            val name = "PhotoCraft_${System.currentTimeMillis()}.jpg"
            val values = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PhotoCraft"); put(MediaStore.Images.Media.IS_PENDING, 1) }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("Storage unavailable")
            contentResolver.openOutputStream(uri).use { stream: OutputStream? -> if (stream == null || !edited.compress(Bitmap.CompressFormat.JPEG, 98, stream)) throw IllegalStateException("JPEG export failed") }
            values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0); contentResolver.update(uri, values, null, null)
            toast("Saved to Pictures/PhotoCraft · JPEG 98%")
            edited.recycle()
        } catch (e: OutOfMemoryError) { toast("Photo is too large for available memory") } catch (e: Exception) { toast("Export failed: ${e.message ?: "unknown error"}") }
    }

    private fun label(text: String) = TextView(this).apply { this.text = text; textSize = 10f; letterSpacing = .12f; setTextColor(ACCENT); setPadding(0, dp(2), 0, dp(8)) }
    private fun smallButton(text: String, click: () -> Unit) = Button(this).apply { this.text = text; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(PANEL); setOnClickListener { click() }; minWidth = dp(42); minimumHeight = dp(38); setPadding(dp(8), 0, dp(8), 0) }
    private fun actionButton(text: String, primary: Boolean, click: () -> Unit) = Button(this).apply { this.text = text; textSize = 12f; isAllCaps = false; setTextColor(if (primary) BG else Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(if (primary) ACCENT else 0xFF292C33.toInt()); setOnClickListener { click() }; minHeight = dp(42); minimumHeight = dp(42); setPadding(dp(8), 0, dp(8), 0) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { super.onDestroy(); if (isFinishing) { previewBitmap?.let { if (it !== original && !it.isRecycled) it.recycle() } } }
}

private fun hueDistance(a: Float, b: Float): Float { val d = kotlin.math.abs(a - b) % 360f; return min(d, 360f - d) }

private fun rgbToHsl(r: Float, g: Float, b: Float): FloatArray {
    val maxC = max(r, max(g, b)); val minC = min(r, min(g, b)); val delta = maxC - minC
    var h = 0f; val l = (maxC + minC) / 2f
    var sat = 0f
    if (delta > 0f) {
        sat = delta / (1f - kotlin.math.abs(2f * l - 1f)).coerceAtLeast(.0001f)
        h = when (maxC) { r -> 60f * (((g - b) / delta) % 6f); g -> 60f * ((b - r) / delta + 2f); else -> 60f * ((r - g) / delta + 4f) }
        if (h < 0f) h += 360f
    }
    return floatArrayOf(h, sat, l)
}

private fun hslToRgb(hue: Float, sat: Float, light: Float): FloatArray {
    val h = ((hue % 360f) + 360f) % 360f; val c = (1f - kotlin.math.abs(2f * light - 1f)) * sat
    val x = c * (1f - kotlin.math.abs((h / 60f) % 2f - 1f)); val m = light - c / 2f
    val rgb = when { h < 60f -> floatArrayOf(c, x, 0f); h < 120f -> floatArrayOf(x, c, 0f); h < 180f -> floatArrayOf(0f, c, x); h < 240f -> floatArrayOf(0f, x, c); h < 300f -> floatArrayOf(x, 0f, c); else -> floatArrayOf(c, 0f, x) }
    return floatArrayOf(rgb[0] + m, rgb[1] + m, rgb[2] + m)
}

private class ColorWheelView(context: android.content.Context, initialHue: Float, val onHueChanged: (Float) -> Unit) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var hue = initialHue
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val radius = min(width / 2f - 18f, height / 2f - 8f).coerceAtLeast(10f)
        val cx = width / 2f; val cy = height / 2f
        paint.shader = android.graphics.SweepGradient(cx, cy, intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, 0xFFFF00FF.toInt(), Color.RED), null)
        canvas.drawCircle(cx, cy, radius, paint); paint.shader = null
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 10f; paint.color = PANEL; canvas.drawCircle(cx, cy, radius - 5f, paint); paint.style = Paint.Style.FILL
        val angle = Math.toRadians((hue * 180f).toDouble())
        val mx = cx + kotlin.math.cos(angle).toFloat() * (radius - 5f); val my = cy + kotlin.math.sin(angle).toFloat() * (radius - 5f)
        paint.color = Color.WHITE; canvas.drawCircle(mx, my, 9f, paint); paint.color = Color.BLACK; canvas.drawCircle(mx, my, 5f, paint)
        paint.color = MUTED; paint.textSize = 11f; canvas.drawText("DRAG TO CHOOSE TINT", 10f, height - 3f, paint)
    }
    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action == android.view.MotionEvent.ACTION_DOWN || event.action == android.view.MotionEvent.ACTION_MOVE || event.action == android.view.MotionEvent.ACTION_UP) {
            val angle = Math.toDegrees(kotlin.math.atan2((event.y - height / 2f).toDouble(), (event.x - width / 2f).toDouble()))
            hue = (angle / 180.0).toFloat().coerceIn(-1f, 1f); onHueChanged(hue); invalidate(); return true
        }
        return true
    }
}

private data class EditState(val values: MutableMap<String, Float> = mutableMapOf(), val filter: String = "Original") {
    fun deepCopy() = EditState(values.toMutableMap(), filter)
}
private fun Float.absoluteValue() = kotlin.math.abs(this)
