plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
}

android {
    namespace = "com.prabhat.photocraft"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.prabhat.photocraft"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0-rebuilt"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
